package Ex2;

public class AnimalTest2 {

	public static void main(String[] args) {
		Animal c = new Cat();
		Animal d = new Dog();
		c.sound();
		d.sound();

	}
}
