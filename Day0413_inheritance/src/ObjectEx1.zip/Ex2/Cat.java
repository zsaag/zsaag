package Ex2;

public class Cat extends Animal {
	public Cat() {

	}

	public Cat(String name, int numOfLegs) {
		this.name = "야옹이";
		this.numOfLegs = 4;
	}

	public void meow() {
		System.out.println("야옹");
	}
	public void sound() {
		System.out.println("야옹");
	}
}
