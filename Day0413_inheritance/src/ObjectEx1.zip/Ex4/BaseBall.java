package Ex4;

public class BaseBall extends SportsPlayer{ //baseball 상속 받기
	private int safety;
	private int homerun;
	private int out;
	
	
	
	public int getSafety() {
		return safety;
	}
	public void setSafety(int safety) {
		this.safety = safety;
	}
	public int getHomerun() {
		return homerun;
	}
	public void setHomerun(int homerun) {
		this.homerun = homerun;
	}
	public int getOut() {
		return out;
	}
	public void setOut(int out) {
		this.out = out;
	}
	public BaseBall() {//기본생성자
		
	}
	public BaseBall(String type,String name, String temper,int age,int career,int weeklysalary,int safety, int homerun,int out) { //생성자
		this.type=type;
		this.name=name;
		this.temper=temper;
		this.age=age;
		this.career=career;
		this.weeklysalary=weeklysalary;
		this.safety=safety;
		this.homerun=homerun;
		this.out=out;
		
	}



@Override
	public String toString() {
		return "BaseBall [safety=" + safety + ", homerun=" + homerun + ", out=" + out + ", name=" + name + ", temper="
				+ temper + ", age=" + age + ", career=" + career + ", weeklysalary=" + weeklysalary + "]";
	}
public void play(){ //등록,조회,검색 이후 해당 운동선수 정보 출력 함수
	System.out.println("야구선수입니다.");
}
}