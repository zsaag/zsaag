package Ex4;

public class BasketBall extends SportsPlayer{
	private int twopoint;
	private int threepoint;
	private int freepoint;
	public int getTwopoint() {
		return twopoint;
	}
	public void setTwopoint(int twopoint) {
		this.twopoint = twopoint;
	}
	public int getThreepoint() {
		return threepoint;
	}
	public void setThreepoint(int threepoint) {
		this.threepoint = threepoint;
	}
	public int getFreepoint() {
		return freepoint;
	}
	public void setFreepoint(int freepoint) {
		this.freepoint = freepoint;
	}
	public BasketBall() {
		
	}
	public BasketBall(String type,String name, String temper,int age,int career,int weeklysalary,int twopoint, int threepoint,int freepoint) { //생성자
		this.type=type;
		this.name=name;
		this.temper=temper;
		this.age=age;
		this.career=career;
		this.weeklysalary=weeklysalary;
		this.twopoint=twopoint;
		this.threepoint=threepoint;
		this.freepoint=freepoint;
	}

@Override
	public String toString() {
		return "BasketBall [twopoint=" + twopoint + ", threepoint=" + threepoint + ", freepoint=" + freepoint
				+ ", name=" + name + ", temper=" + temper + ", age=" + age + ", career=" + career + ", weeklysalary="
				+ weeklysalary + "]";
	}
public void play(){ //등록,조회,검색 이후 해당 운동선수 정보 출력 함수
	System.out.println("농구선수입니다");
}

}