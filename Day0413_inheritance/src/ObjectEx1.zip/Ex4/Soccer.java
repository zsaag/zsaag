package Ex4;

public class Soccer extends SportsPlayer{
	private String position;
	private int goal;
	private int assist;
	
	public String getPosition() {
		return position;
	}
	
	
	@Override
	public String toString() {
		return "Soccer [position=" + position + ", goal=" + goal + ", assist=" + assist + ", type=" + type + ", name="
				+ name + ", temper=" + temper + ", age=" + age + ", career=" + career + ", weeklysalary=" + weeklysalary
				+ "]";
	}


	public void setPosition(String position) {
		this.position = position;
	}
	public int getGoal() {
		return goal;
	}
	public void setGoal(int goal) {
		this.goal = goal;
	}
	public int getAssist() {
		return assist;
	}
	public void setAssist(int assist) {
		this.assist = assist;
	}

	public Soccer() {
				
		
	}
	public Soccer(String type,String name, String temper,int age,int career,int weeklysalary,String position, int goal, int assist) { //생성자
	this.type=type;
	this.name=name;
	this.temper=temper;
	this.age=age;
	this.career=career;
	this.weeklysalary=weeklysalary;
	this.position=position;
	this.goal=goal;
	this.assist=assist;
	
	}
	
	public void play(){ //등록,조회,검색 이후 해당 운동선수 정보 출력 함수
	System.out.println("축구선수입니다.");
	}
}