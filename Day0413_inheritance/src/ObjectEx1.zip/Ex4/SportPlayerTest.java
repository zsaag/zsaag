package Ex4;

public class SportPlayerTest {
	public static void main(String[] args) {

		SportsAgency sa= new SportsAgency();
		
		sa.start();  //프로그램 시작
		}
	}

