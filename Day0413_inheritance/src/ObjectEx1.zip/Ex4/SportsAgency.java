package Ex4;

import java.util.Scanner;


public class SportsAgency extends SportsPlayer{ //운동선수 속성
	private SportsPlayer[] sportplayer; //운동선수 저장을 위한 배열
	private int number;    //운동선수 저장을 위한 배열
	private boolean isRun; //프로그램을 계속 실행할 것인지 확인하는 변수
	private Scanner input; //입력을 위한 변수
	 
	
	
	public SportsAgency() {
		sportplayer = new SportsPlayer[50];
		//isRun의 초기값을 true로 줘서 프로그램이 실행될 수 있도록 한다.
		isRun = true; 
		input = new Scanner(System.in);
		setData();
	}
	
	
	public void start() {
		//메뉴를 계속해서 출력하기 위해서 while문에서 메뉴를 출력한다.
		while(isRun) {
			showMenu();
			inputMenu();
		}
	}
	
	
	// 메뉴 보여주기
	public void showMenu() {
		System.out.println("******** 메뉴를 선택 하세요 *******");
		System.out.println("* 1. 운동선수등록           2.조회            *");
		System.out.println("* 3. 검색                       4. 종료          *");
		System.out.println("***************************");
	}
	
	// 메뉴 입력받기
	public void inputMenu() {
		input = new Scanner(System.in);
		int menu = input.nextInt();
		
		switch (menu) {
		case 1:
			//등록
			//input();
			break;
		case 2:
			//조회
			showSportsPlayer();
			break;
		case 3:
			//검색
			searchStudent();
			break;
		case 4:
			//종료
			System.out.println("종료합니다.");
			isRun = false;  //프로그램을 종료하기 위해서 상태값을 false로 변경
			break;
		default:
			//메뉴 없음
			System.out.println("잘못입력하셨습니다.");
			break;
		}
	}
	

	/*public void input() { //운동선수 추가 메서드
		String t;//선수 타입입력
		t = input.next();
		
		System.out.println("타입");
		type = input.next();
		System.out.println("이름");
		name = input.next();
		System.out.println("소속");
		temper = input.next();
		System.out.println("나이");
		age = input.nextInt();
		System.out.println("경력");
		career = input.nextInt();
		System.out.println("주급");
		weeklysalary = input.nextInt();
		input.next();
		if(type=="축구")
		{
		System.out.println("포지션");
		position = input.next();
		System.out.println("포지션");
		goal = input.nextInt();
		System.out.println("포지션");
		assist = input.nextInt();
		
		
		
		sportplayer[number] = new Soccer(type,name,temper,age,career,weeklysalary,position,goal,assist);
		number++;
		}
		System.out.println("추가되었습니다.");
		System.out.println();
		}
	*/
	public void showSportsPlayer() {//모든 선수 조회 메서드
		 {
			for(int i=0;i<number;i++){
			{
				System.out.println(sportplayer[i]);
			}
		  }
		}
	}
	
	public void searchStudent() {
		//System.out.println("학생정보 검색하기");
		//이름검색
		//사용자에게 문자열을 입력받아서 해당 문자열을 포함하는 이름을 가진
		//학생을 모두출력
		//문자열을 하나 입력받고
		//내가 가진 학생배열을 하나씩 검색하면서, 
		//입력받은 문자열과 이름을 비교해서 같거나, 문자열을 포함하고 있으면
		//학생정보를 출력
		System.out.println("이름을 입력하세요");
		String keyword = input.next();
		
		for(int i=0;i<number;i++) {
			//students[i].getName()와 keyword 비교
			
			String name = sportplayer[i].getName();
			for (SportsPlayer a : sportplayer)
			{
				a.play();
			}
			//문자열 비교 :  equals(), contains(s)
			//name.equals(keyword);
			//name 문자열이 keyword를 포함하고 있으면 true, 아니면 false
			//name.contains(keyword);
		}
	}
		
	public void setData() {
		//학생배열에 3~4명정도 학생정보 넣기
		sportplayer[0] = new Soccer("축구","메시","바르셀로나",30,10,5,"공격수",40,40);
		sportplayer[1] = new BasketBall("농구","르브론제임스","클리븐랜드 캐버리어스",33,11,4,20,30,20);
		sportplayer[2] = new BaseBall("야구","추신수","텍사스 레인저스",35,13,6,10,5,6);
		number = 3;
	}
}