package Ex4;

public class SportsPlayer {
	protected String type; //유형
	protected String name; //이름
	protected String temper; //소속
	protected int age; //나이
	protected int career; //경력
	protected int weeklysalary; //주급
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public SportsPlayer() { //기본생성자
		
	}
	public SportsPlayer(String type, String name, String temper,int age,int career,int weeklysalary) { //생성자
		this.type=type;
		this.name=name;
		this.temper=temper;
		this.age=age;
		this.career=career;
		this.weeklysalary=weeklysalary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTemper() {
		return temper;
	}
	public void setTemper(String temper) {
		this.temper = temper;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getCareer() {
		return career;
	}
	public void setCareer(int career) {
		this.career = career;
	}
	public int getWeekSalary() {
		return weeklysalary;
	}
	public void getWeekSalary(int weeklysalary) {
		this.weeklysalary=weeklysalary;
	}
	public void play(){ //등록,조회,검색 이후 해당 운동선수 정보 출력 함수
		System.out.println("운동선수입니다.");	
	}
}

