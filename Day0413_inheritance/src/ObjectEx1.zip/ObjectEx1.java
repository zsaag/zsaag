
public class ObjectEx1 {

}
